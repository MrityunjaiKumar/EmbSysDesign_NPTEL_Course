#include <msp430.h>
#include <stdio.h>
#include <string.h>

#define UART_PRINTF

#ifdef UART_PRINTF
int fputc(int _c, register FILE *_fp);
int fputs(const char *_ptr, register FILE *_fp);
#endif

void main(void)
{
    unsigned int counter=0;
    WDTCTL = WDTPW + WDTHOLD;           // Stop Watchdog

    P1SEL = BIT1 + BIT2 ;               // Select UART RX/TX function on P1.1,P1.2
    P1SEL2 = BIT1 + BIT2;

    UCA0CTL1 |= UCSSEL_1;               // UART Clock -> ACLK
    UCA0BR0 = 3;                        // Baud Rate Setting for 1MHz 9600
    UCA0BR1 = 0;                        // Baud Rate Setting for 1MHz 9600
    UCA0MCTL = UCBRF_0 + UCBRS_3;       // Modulation Setting for 1MHz 9600
    UCA0MCTL &= ~UCOS16;
    UCA0CTL1 &= ~UCSWRST;               // Initialize UART Module
    IE2 |= UCA0RXIE;                    // Enable RX interrupt
    int i = 0;
    while(1)
      {
        //__bis_SR_register(LPM0_bits+GIE);       // Enter LPM3, enable interrupts
        printf("Hello world %d!\r\n", counter++);
        for(i = 0; i < 2000; i++);
      }
}

/*
#pragma vector=USCIAB0RX_VECTOR         // UART RX Interrupt Vector
__interrupt void USCI0RX_ISR(void)
{
    while (!(IFG2&UCA0TXIFG));          // Check if TX is ongoing
    UCA0TXBUF = UCA0RXBUF;              // TX -> Received Char + 1
    P1OUT ^= BIT7;
}
*/

#ifdef UART_PRINTF
int fputc(int _c, register FILE *_fp)
{
  while(!(IFG2&UCA0TXIFG));
  UCA0TXBUF = (unsigned char) _c;

  return((unsigned char)_c);
}

int fputs(const char *_ptr, register FILE *_fp)
{
  unsigned int i, len;

  len = strlen(_ptr);

  for(i=0 ; i<len ; i++)
  {
    while(!(IFG2&UCA0TXIFG));
    UCA0TXBUF = (unsigned char) _ptr[i];
  }

  return len;
}
#endif
